ZC SNARE EXTRACT v3.0 - Limp Bizkit - "Making Love To Morgan Wallen" (mixed by Zakk Cervini)
=====================================================================
All files: 48 kHz / 24-bit stereo WAV, trimmed to the stick hit, peak-normalised as a set (loudest hard hit = -1 dBFS).

WHAT THESE ARE
Real snare hits lifted off the record. Nothing is synthesised, nothing is EQ'd, no averaging in the audible part.
 1. Two-stage source separation: Demucs htdemucs (song -> drums) then MDX23C DrumSep by aufr33 & jarredou
    (drums -> kick / snare / toms / hi-hat / ride / crash). Everything below is done on the snare-only stem.
 2. 171 snare hits located and sub-sample aligned on the snare stem (median waveform correlation 0.816,
    hit-to-hit level SD 15.31 dB).
 3. Audit of what the separator did at the snare onsets (mean over all hits, dBFS):
      0-5 ms   snare stem -9.6  vs full drum stem -9.2  (transient intact; difference is the hat/kick share)
      5-30 ms  snare stem -11.4  vs drum stem -11.2
    Hit-locked energy left in the separator residual (snare that got dropped): -46.4 dBFS at 0-5 ms vs -12.4 dBFS of snare -> negligible.
    Snare stem minus drum stem, first 60 ms, per band (dB): {'60-150': -4.7, '150-300': -0.0, '300-600': -0.1, '600-1200': -0.1, '1200-2500': -0.1, '2500-5000': -0.7, '5000-8000': -1.0, '8000-12000': -2.0, '12000-16000': -4.1}
    (only the sub band where the kick lives and 8-16 kHz where the hat lives lost level; 150 Hz - 8 kHz is within ~1 dB).
 4. Each file is ONE real hit, full length, with its own transient, body, wires and reverb as it sits on the record.
    The real tail is used for as long as it stays 6 dB above the background measured 20..5 ms before that same hit
    (previous tails, cymbal wash, bleed). Below that level the hit is inaudible under the record anyway; that remainder
    is continued per band with the hit's own late texture at the decay rate measured on this song (ESTIMATE, see below)
    and the file ends where the level is under -88 dBFS. Hits were picked for long clean air before the next snare,
    low background, typical envelope and no coincident kick (40-120 Hz excess test).
 5. Onset: STFT separators smear ~15 ms of pre-echo ahead of the stick; the true onset was read off the time-domain drum
    stem (1 kHz high-passed) and the file starts 0.3 ms before it. Attack-to-peak in the files: [4.04, 2.9, 4.67, 3.31] ms (hard rr1-4).
    Real quiet-layer hits sit in busy context (kick/hat right before them), where that walk-back stops under the peak and
    clips the attack; those files instead start 0.5 ms before the snare stem's own 1 ms envelope last crossed -10.5 dB re its
    attack peak (1 ms fade-in). Every file starts >= 13 dB below its own peak.

MEASURED DECAY (per-hit linear fit in dB on each hit's own clean range, song value = median over hits)
  bands <150 / 150-600 / 600-2k / 2-6k / >6k Hz, late part (150 ms on): [-103.0, -95.0, -89.0, -110.0, -136.0] dB/s  ->  T60 [0.58, 0.63, 0.67, 0.54, 0.44] s
  early part (60-150 ms, body + early reflections): [None, -85.0, -81.0, -89.0, -124.0] dB/s
  Median envelope of all hits relative to peak (dB): {'10ms': 0.0, '30ms': -8.0, '50ms': -7.3, '100ms': -13.6, '150ms': -17.3, '200ms': -22.2, '300ms': -28.9}
  Snare-stem noise floor between hits: -80.4 dBFS.

LAYERS (this record contains real quieter snare hits, so the quieter layers are REAL hits at their REAL level, not transforms)
 Every aligned hit was levelled against the loud cluster (75th percentile of hit gain = 0 dB). Velocity bands: hard >= -3 dB,
 medium -10..-3 dB, soft -18..-10 dB, ghost < -18 dB. Each layer takes the 4 cleanest real hits in its band (same tail/background/
 kick tests as the hard hits). Real hits in this pack: hard 4/4, medium 4/4, soft 4/4, ghost 2/4.
 Any slot marked ESTIMATE below is a hard hit with the lighter-stroke transform used on the other packs (nominal -6/-12/-20 dB).
 Levels of the real quiet hits are the record's own (see rel dB per file below); hard rr1-4 keep the record's natural +/-1.5 dB spread.
 ZC_lb_oneshot.wav = hard rr1.

THE 16 HITS (time in song, air before next snare, background under the tail rel. peak, real tail used to, file length)
  hard rr1: t=67.92 s, gap 715 ms, bg -43.1 dB, real to 329 ms, len 786 ms, rel 0.3 dB REAL
  hard rr2: t=134.21 s, gap 689 ms, bg -41.8 dB, real to 269 ms, len 780 ms, rel 0.6 dB REAL
  hard rr3: t=136.49 s, gap 594 ms, bg -45.0 dB, real to 284 ms, len 756 ms, rel 0.3 dB REAL
  hard rr4: t=81.63 s, gap 626 ms, bg -39.0 dB, real to 259 ms, len 656 ms, rel 0.4 dB REAL
  medium rr1: t=37.48 s, gap 148 ms, bg -34.1 dB, real to 133 ms, len 541 ms, rel -9.2 dB REAL
  medium rr2: t=108.32 s, gap 438 ms, bg -33.3 dB, real to 149 ms, len 717 ms, rel -6.4 dB REAL
  medium rr3: t=134.91 s, gap 188 ms, bg -34.0 dB, real to 149 ms, len 731 ms, rel -5.9 dB REAL
  medium rr4: t=206.62 s, gap 129 ms, bg -23.7 dB, real to 114 ms, len 543 ms, rel -7.4 dB REAL
  soft rr1: t=38.92 s, gap 260 ms, bg -17.1 dB, real to 149 ms, len 456 ms, rel -15.9 dB REAL
  soft rr2: t=183.19 s, gap 178 ms, bg -25.6 dB, real to 149 ms, len 633 ms, rel -13.8 dB REAL
  soft rr3: t=185.79 s, gap 269 ms, bg -15.3 dB, real to 149 ms, len 648 ms, rel -15.7 dB REAL
  soft rr4: t=114.64 s, gap 128 ms, bg -17.6 dB, real to 113 ms, len 551 ms, rel -14.7 dB REAL
  ghost rr1: t=169.48 s, gap 174 ms, bg -18.7 dB, real to 149 ms, len 585 ms, rel -20.7 dB REAL
  ghost rr2: t=117.47 s, gap 149 ms, bg -14.0 dB, real to 134 ms, len 610 ms, rel -21.8 dB REAL
  ghost rr3: t=213.05 s, gap 488 ms, bg -45.2 dB, real to 264 ms, len 691 ms, rel -20 dB ESTIMATE
  ghost rr4: t=237.65 s, gap 470 ms, bg -42.1 dB, real to 455 ms, len 904 ms, rel -20 dB ESTIMATE