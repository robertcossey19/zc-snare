ZC SNARE EXTRACT v3.0 - Architects - "Blackhole" (mixed by Zakk Cervini)
=====================================================================
All files: 48 kHz / 24-bit stereo WAV, trimmed to the stick hit, peak-normalised as a set (loudest hard hit = -1 dBFS).

WHAT THESE ARE
Real snare hits lifted off the record. Nothing is synthesised, nothing is EQ'd, no averaging in the audible part.
 1. Two-stage source separation: Demucs htdemucs (song -> drums) then MDX23C DrumSep by aufr33 & jarredou
    (drums -> kick / snare / toms / hi-hat / ride / crash). Everything below is done on the snare-only stem.
 2. 141 snare hits located and sub-sample aligned on the snare stem (median waveform correlation 0.933,
    hit-to-hit level SD 1.66 dB).
 3. Audit of what the separator did at the snare onsets (mean over all hits, dBFS):
      0-5 ms   snare stem -9.7  vs full drum stem -9.3  (transient intact; difference is the hat/kick share)
      5-30 ms  snare stem -9.2  vs drum stem -8.7
    Hit-locked energy left in the separator residual (snare that got dropped): -42.8 dBFS at 0-5 ms vs -11.3 dBFS of snare -> negligible.
    Snare stem minus drum stem, first 60 ms, per band (dB): {'60-150': -19.2, '150-300': -0.1, '300-600': -0.3, '600-1200': -0.3, '1200-2500': -0.6, '2500-5000': -1.2, '5000-8000': -1.4, '8000-12000': -3.1, '12000-16000': -5.8}
    (only the sub band where the kick lives and 8-16 kHz where the hat lives lost level; 150 Hz - 8 kHz is within ~1 dB).
 4. Each file is ONE real hit, full length, with its own transient, body, wires and reverb as it sits on the record.
    The real tail is used for as long as it stays 6 dB above the background measured 20..5 ms before that same hit
    (previous tails, cymbal wash, bleed). Below that level the hit is inaudible under the record anyway; that remainder
    is continued per band with the hit's own late texture at the decay rate measured on this song (ESTIMATE, see below)
    and the file ends where the level is under -88 dBFS. Hits were picked for long clean air before the next snare,
    low background, typical envelope and no coincident kick (40-120 Hz excess test).
 5. Onset: STFT separators smear ~15 ms of pre-echo ahead of the stick; the true onset was read off the time-domain drum
    stem (1 kHz high-passed) and the file starts 0.3 ms before it. Attack-to-peak in the files: [1.66, 2.29, 0.63, 2.34] ms (hard rr1-4).

MEASURED DECAY (per-hit linear fit in dB on each hit's own clean range, song value = median over hits)
  bands <150 / 150-600 / 600-2k / 2-6k / >6k Hz, late part (150 ms on): [-97.0, -107.0, -85.0, -86.0, -121.0] dB/s  ->  T60 [0.62, 0.56, 0.71, 0.7, 0.5] s
  early part (60-150 ms, body + early reflections): [None, -107.0, -85.0, -86.0, -121.0] dB/s
  Median envelope of all hits relative to peak (dB): {'10ms': 0.0, '30ms': -9.0, '50ms': -14.2, '100ms': -16.0, '150ms': -20.9, '200ms': -31.0}
  Snare-stem noise floor between hits: -82.8 dBFS.

LAYERS
 hard   rr1-4 : four distinct real hits, untouched (hard = how the record was played).
 medium rr1-4 : four other real hits with physics-informed lighter-stroke transforms (ESTIMATE - the record has no quiet hits):
                nominal -6 dB, gentle tilt above 3 kHz (-2.5 dB), wire decay x0.9, pitch glide x0.8, attack x0.95.
 soft   rr1-4 : four other real hits: nominal -12 dB, tilt above 2 kHz (-5 dB), wire decay x0.75, glide x0.5, attack x0.85.
 ghost  rr1-4 : four other real hits: nominal -20 dB, tilt above 1.5 kHz (-8 dB) + above 5 kHz (-4 dB), wire decay x0.6, glide x0.3, attack x0.7.
 Each layer has +/-0.7 dB random level scatter so no two files are volume copies.
 ZC_arch_oneshot.wav = hard rr1.

THE 16 HITS (time in song, air before next snare, background under the tail rel. peak, real tail used to, file length)
  hard rr1: t=161.22 s, gap 1491 ms, bg -40.3 dB, real to 184 ms, len 689 ms
  hard rr2: t=59.22 s, gap 1493 ms, bg -34.1 dB, real to 184 ms, len 766 ms
  hard rr3: t=124.29 s, gap 555 ms, bg -45.0 dB, real to 249 ms, len 617 ms
  hard rr4: t=155.22 s, gap 1493 ms, bg -32.6 dB, real to 184 ms, len 789 ms
  medium rr1: t=44.6 s, gap 501 ms, bg -40.8 dB, real to 349 ms, len 814 ms
  medium rr2: t=104.6 s, gap 378 ms, bg -42.9 dB, real to 329 ms, len 755 ms
  medium rr3: t=195.72 s, gap 366 ms, bg -38.8 dB, real to 179 ms, len 749 ms
  medium rr4: t=42.97 s, gap 1109 ms, bg -18.6 dB, real to 149 ms, len 748 ms
  soft rr1: t=24.35 s, gap 363 ms, bg -41.5 dB, real to 284 ms, len 749 ms
  soft rr2: t=28.85 s, gap 360 ms, bg -43.3 dB, real to 345 ms, len 734 ms
  soft rr3: t=77.22 s, gap 293 ms, bg -39.1 dB, real to 219 ms, len 724 ms
  soft rr4: t=183.72 s, gap 306 ms, bg -41.7 dB, real to 291 ms, len 719 ms
  ghost rr1: t=22.85 s, gap 289 ms, bg -48.5 dB, real to 274 ms, len 667 ms
  ghost rr2: t=160.38 s, gap 837 ms, bg -15.9 dB, real to 149 ms, len 671 ms
  ghost rr3: t=31.47 s, gap 559 ms, bg -14.4 dB, real to 149 ms, len 752 ms
  ghost rr4: t=136.38 s, gap 837 ms, bg -15.4 dB, real to 149 ms, len 673 ms