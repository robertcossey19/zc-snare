ZC SNARE EXTRACT v3.0 - Nothing More - "If It Doesn't Hurt" (mixed by Zakk Cervini)
=====================================================================
All files: 48 kHz / 24-bit stereo WAV, trimmed to the stick hit, peak-normalised as a set (loudest hard hit = -1 dBFS).

WHAT THESE ARE
Real snare hits lifted off the record. Nothing is synthesised, nothing is EQ'd, no averaging in the audible part.
 1. Two-stage source separation: Demucs htdemucs (song -> drums) then MDX23C DrumSep by aufr33 & jarredou
    (drums -> kick / snare / toms / hi-hat / ride / crash). Everything below is done on the snare-only stem.
 2. 116 snare hits located and sub-sample aligned on the snare stem (median waveform correlation 0.923,
    hit-to-hit level SD 2.5 dB).
 3. Audit of what the separator did at the snare onsets (mean over all hits, dBFS):
      0-5 ms   snare stem -9.7  vs full drum stem -9.0  (transient intact; difference is the hat/kick share)
      5-30 ms  snare stem -11.5  vs drum stem -10.8
    Hit-locked energy left in the separator residual (snare that got dropped): -42.9 dBFS at 0-5 ms vs -11.8 dBFS of snare -> negligible.
    Snare stem minus drum stem, first 60 ms, per band (dB): {'60-150': -15.1, '150-300': -0.4, '300-600': -0.4, '600-1200': -0.3, '1200-2500': -0.3, '2500-5000': -1.3, '5000-8000': -1.9, '8000-12000': -3.5, '12000-16000': -5.8}
    (only the sub band where the kick lives and 8-16 kHz where the hat lives lost level; 150 Hz - 8 kHz is within ~1 dB).
 4. Each file is ONE real hit, full length, with its own transient, body, wires and reverb as it sits on the record.
    The real tail is used for as long as it stays 6 dB above the background measured 20..5 ms before that same hit
    (previous tails, cymbal wash, bleed). Below that level the hit is inaudible under the record anyway; that remainder
    is continued per band with the hit's own late texture at the decay rate measured on this song (ESTIMATE, see below)
    and the file ends where the level is under -88 dBFS. Hits were picked for long clean air before the next snare,
    low background, typical envelope and no coincident kick (40-120 Hz excess test).
 5. Onset: STFT separators smear ~15 ms of pre-echo ahead of the stick; the true onset was read off the time-domain drum
    stem (1 kHz high-passed) and the file starts 0.3 ms before it. Attack-to-peak in the files: [3.92, 1.22, 1.86, 1.11] ms (hard rr1-4).

MEASURED DECAY (per-hit linear fit in dB on each hit's own clean range, song value = median over hits)
  bands <150 / 150-600 / 600-2k / 2-6k / >6k Hz, late part (150 ms on): [-118.0, -98.0, -128.0, -109.0, -161.0] dB/s  ->  T60 [0.51, 0.61, 0.47, 0.55, 0.37] s
  early part (60-150 ms, body + early reflections): [None, -141.0, -107.0, -98.0, -161.0] dB/s
  Median envelope of all hits relative to peak (dB): {'10ms': 0.0, '30ms': -12.9, '50ms': -10.3, '100ms': -16.8, '150ms': -22.2, '200ms': -28.0}
  Snare-stem noise floor between hits: -83.7 dBFS.

LAYERS
 hard   rr1-4 : four distinct real hits, untouched (hard = how the record was played).
 medium rr1-4 : four other real hits with physics-informed lighter-stroke transforms (ESTIMATE - the record has no quiet hits):
                nominal -6 dB, gentle tilt above 3 kHz (-2.5 dB), wire decay x0.9, pitch glide x0.8, attack x0.95.
 soft   rr1-4 : four other real hits: nominal -12 dB, tilt above 2 kHz (-5 dB), wire decay x0.75, glide x0.5, attack x0.85.
 ghost  rr1-4 : four other real hits: nominal -20 dB, tilt above 1.5 kHz (-8 dB) + above 5 kHz (-4 dB), wire decay x0.6, glide x0.3, attack x0.7.
 Each layer has +/-0.7 dB random level scatter so no two files are volume copies.
 ZC_nm_oneshot.wav = hard rr1.

THE 16 HITS (time in song, air before next snare, background under the tail rel. peak, real tail used to, file length)
  hard rr1: t=41.66 s, gap 1255 ms, bg -37.2 dB, real to 214 ms, len 664 ms
  hard rr2: t=160.08 s, gap 938 ms, bg -43.1 dB, real to 254 ms, len 659 ms
  hard rr3: t=87.14 s, gap 1255 ms, bg -37.0 dB, real to 259 ms, len 729 ms
  hard rr4: t=133.24 s, gap 625 ms, bg -43.9 dB, real to 319 ms, len 725 ms
  medium rr1: t=119.35 s, gap 783 ms, bg -34.5 dB, real to 154 ms, len 659 ms
  medium rr2: t=84.61 s, gap 1255 ms, bg -33.5 dB, real to 219 ms, len 689 ms
  medium rr3: t=70.71 s, gap 625 ms, bg -41.4 dB, real to 279 ms, len 684 ms
  medium rr4: t=104.82 s, gap 471 ms, bg -46.1 dB, real to 329 ms, len 639 ms
  soft rr1: t=121.87 s, gap 459 ms, bg -43.5 dB, real to 224 ms, len 666 ms
  soft rr2: t=164.66 s, gap 468 ms, bg -42.6 dB, real to 249 ms, len 672 ms
  soft rr3: t=167.98 s, gap 2515 ms, bg -24.8 dB, real to 164 ms, len 742 ms
  soft rr4: t=131.98 s, gap 469 ms, bg -42.9 dB, real to 319 ms, len 709 ms
  ghost rr1: t=47.82 s, gap 468 ms, bg -39.9 dB, real to 259 ms, len 682 ms
  ghost rr2: t=174.77 s, gap 466 ms, bg -33.5 dB, real to 219 ms, len 699 ms
  ghost rr3: t=90.29 s, gap 465 ms, bg -35.6 dB, real to 159 ms, len 644 ms
  ghost rr4: t=106.08 s, gap 474 ms, bg -33.9 dB, real to 149 ms, len 659 ms