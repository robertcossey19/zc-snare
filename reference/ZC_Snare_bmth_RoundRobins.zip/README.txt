ZC SNARE EXTRACT v3.0 - Bring Me The Horizon - "Teardrops" (mixed by Zakk Cervini)
=====================================================================
All files: 48 kHz / 24-bit stereo WAV, trimmed to the stick hit, peak-normalised as a set (loudest hard hit = -1 dBFS).

WHAT THESE ARE
Real snare hits lifted off the record. Nothing is synthesised, nothing is EQ'd, no averaging in the audible part.
 1. Two-stage source separation: Demucs htdemucs (song -> drums) then MDX23C DrumSep by aufr33 & jarredou
    (drums -> kick / snare / toms / hi-hat / ride / crash). Everything below is done on the snare-only stem.
 2. 198 snare hits located and sub-sample aligned on the snare stem (median waveform correlation 0.914,
    hit-to-hit level SD 2.03 dB).
 3. Audit of what the separator did at the snare onsets (mean over all hits, dBFS):
      0-5 ms   snare stem -10.1  vs full drum stem -9.8  (transient intact; difference is the hat/kick share)
      5-30 ms  snare stem -10.4  vs drum stem -10.1
    Hit-locked energy left in the separator residual (snare that got dropped): -49.1 dBFS at 0-5 ms vs -11.0 dBFS of snare -> negligible.
    Snare stem minus drum stem, first 60 ms, per band (dB): {'60-150': -9.1, '150-300': -0.1, '300-600': -0.3, '600-1200': -0.2, '1200-2500': -0.4, '2500-5000': -1.3, '5000-8000': -2.4, '8000-12000': -4.1, '12000-16000': -5.3}
    (only the sub band where the kick lives and 8-16 kHz where the hat lives lost level; 150 Hz - 8 kHz is within ~1 dB).
 4. Each file is ONE real hit, full length, with its own transient, body, wires and reverb as it sits on the record.
    The real tail is used for as long as it stays 6 dB above the background measured 20..5 ms before that same hit
    (previous tails, cymbal wash, bleed). Below that level the hit is inaudible under the record anyway; that remainder
    is continued per band with the hit's own late texture at the decay rate measured on this song (ESTIMATE, see below)
    and the file ends where the level is under -88 dBFS. Hits were picked for long clean air before the next snare,
    low background, typical envelope and no coincident kick (40-120 Hz excess test).
 5. Onset: STFT separators smear ~15 ms of pre-echo ahead of the stick; the true onset was read off the time-domain drum
    stem (1 kHz high-passed) and the file starts 0.3 ms before it. Attack-to-peak in the files: [5.08, 5.87, 5.76, 3.45] ms (hard rr1-4).
    Real quiet-layer hits sit in busy context (kick/hat right before them), where that walk-back stops under the peak and
    clips the attack; those files instead start 0.5 ms before the snare stem's own 1 ms envelope last crossed -10.5 dB re its
    attack peak (1 ms fade-in). Every file starts >= 13 dB below its own peak.

MEASURED DECAY (per-hit linear fit in dB on each hit's own clean range, song value = median over hits)
  bands <150 / 150-600 / 600-2k / 2-6k / >6k Hz, late part (150 ms on): [-85.0, -83.0, -87.0, -58.0, -148.0] dB/s  ->  T60 [0.71, 0.72, 0.69, 1.04, 0.4] s
  early part (60-150 ms, body + early reflections): [None, -147.0, -113.0, -132.0, -157.0] dB/s
  Median envelope of all hits relative to peak (dB): {'10ms': 0.0, '30ms': -5.3, '50ms': -6.4, '100ms': -16.3, '150ms': -21.3, '200ms': -28.7}
  Snare-stem noise floor between hits: -84.2 dBFS.

LAYERS (this record contains real quieter snare hits, so the quieter layers are REAL hits at their REAL level, not transforms)
 Every aligned hit was levelled against the loud cluster (75th percentile of hit gain = 0 dB). Velocity bands: hard >= -3 dB,
 medium -10..-3 dB, soft -18..-10 dB, ghost < -18 dB. Each layer takes the 4 cleanest real hits in its band (same tail/background/
 kick tests as the hard hits). Real hits in this pack: hard 4/4, medium 2/4, soft 0/4, ghost 0/4.
 Any slot marked ESTIMATE below is a hard hit with the lighter-stroke transform used on the other packs (nominal -6/-12/-20 dB).
 Levels of the real quiet hits are the record's own (see rel dB per file below); hard rr1-4 keep the record's natural +/-1.5 dB spread.
 ZC_bmth_oneshot.wav = hard rr1.

THE 16 HITS (time in song, air before next snare, background under the tail rel. peak, real tail used to, file length)
  hard rr1: t=178.03 s, gap 616 ms, bg -36.7 dB, real to 169 ms, len 920 ms, rel -1.8 dB REAL
  hard rr2: t=26.47 s, gap 932 ms, bg -45.2 dB, real to 269 ms, len 814 ms, rel -0.0 dB REAL
  hard rr3: t=186.78 s, gap 618 ms, bg -44.8 dB, real to 209 ms, len 679 ms, rel -0.9 dB REAL
  hard rr4: t=146.78 s, gap 930 ms, bg -36.7 dB, real to 154 ms, len 899 ms, rel -3.0 dB REAL
  medium rr1: t=141.78 s, gap 777 ms, bg -41.7 dB, real to 209 ms, len 754 ms, rel -3.8 dB REAL
  medium rr2: t=144.28 s, gap 838 ms, bg -40.8 dB, real to 159 ms, len 847 ms, rel -3.2 dB REAL
  medium rr3: t=80.22 s, gap 1244 ms, bg -39.4 dB, real to 224 ms, len 929 ms, rel -6 dB ESTIMATE
  medium rr4: t=30.22 s, gap 930 ms, bg -41.7 dB, real to 269 ms, len 881 ms, rel -6 dB ESTIMATE
  soft rr1: t=183.03 s, gap 616 ms, bg -43.5 dB, real to 254 ms, len 704 ms, rel -12 dB ESTIMATE
  soft rr2: t=13.65 s, gap 776 ms, bg -46.3 dB, real to 269 ms, len 729 ms, rel -12 dB ESTIMATE
  soft rr3: t=126.47 s, gap 929 ms, bg -41.8 dB, real to 214 ms, len 764 ms, rel -12 dB ESTIMATE
  soft rr4: t=189.28 s, gap 617 ms, bg -38.6 dB, real to 184 ms, len 809 ms, rel -12 dB ESTIMATE
  ghost rr1: t=180.53 s, gap 617 ms, bg -39.5 dB, real to 244 ms, len 844 ms, rel -20 dB ESTIMATE
  ghost rr2: t=185.53 s, gap 616 ms, bg -38.4 dB, real to 199 ms, len 700 ms, rel -20 dB ESTIMATE
  ghost rr3: t=209.28 s, gap 929 ms, bg -41.6 dB, real to 244 ms, len 836 ms, rel -20 dB ESTIMATE
  ghost rr4: t=188.03 s, gap 617 ms, bg -45.4 dB, real to 234 ms, len 740 ms, rel -20 dB ESTIMATE