ZC SNARE EXTRACT v3.0 - Bring Me The Horizon - "Teardrops" (mixed by Zakk Cervini)
=====================================================================
All files: 48 kHz / 24-bit stereo WAV, trimmed to the stick hit, peak-normalised as a set (loudest hard hit = -1 dBFS).

WHAT THESE ARE
Real snare hits lifted off the record. Nothing is synthesised, nothing is EQ'd, no averaging in the audible part.
 1. Two-stage source separation: Demucs htdemucs (song -> drums) then MDX23C DrumSep by aufr33 & jarredou
    (drums -> kick / snare / toms / hi-hat / ride / crash). Everything below is done on the snare-only stem.
 2. 184 snare hits located and sub-sample aligned on the snare stem (median waveform correlation 0.915,
    hit-to-hit level SD 1.61 dB).
 3. Audit of what the separator did at the snare onsets (mean over all hits, dBFS):
      0-5 ms   snare stem -9.7  vs full drum stem -9.4  (transient intact; difference is the hat/kick share)
      5-30 ms  snare stem -9.9  vs drum stem -9.6
    Hit-locked energy left in the separator residual (snare that got dropped): -47.6 dBFS at 0-5 ms vs -11.3 dBFS of snare -> negligible.
    Snare stem minus drum stem, first 60 ms, per band (dB): {'60-150': -9.8, '150-300': -0.1, '300-600': -0.3, '600-1200': -0.2, '1200-2500': -0.4, '2500-5000': -1.3, '5000-8000': -2.3, '8000-12000': -4.1, '12000-16000': -5.3}
    (only the sub band where the kick lives and 8-16 kHz where the hat lives lost level; 150 Hz - 8 kHz is within ~1 dB).
 4. Each file is ONE real hit, full length, with its own transient, body, wires and reverb as it sits on the record.
    The real tail is used for as long as it stays 6 dB above the background measured 20..5 ms before that same hit
    (previous tails, cymbal wash, bleed). Below that level the hit is inaudible under the record anyway; that remainder
    is continued per band with the hit's own late texture at the decay rate measured on this song (ESTIMATE, see below)
    and the file ends where the level is under -88 dBFS. Hits were picked for long clean air before the next snare,
    low background, typical envelope and no coincident kick (40-120 Hz excess test).
 5. Onset: STFT separators smear ~15 ms of pre-echo ahead of the stick; the true onset was read off the time-domain drum
    stem (1 kHz high-passed) and the file starts 0.3 ms before it. Attack-to-peak in the files: [5.85, 3.56, 2.59, 3.24] ms (hard rr1-4).

MEASURED DECAY (per-hit linear fit in dB on each hit's own clean range, song value = median over hits)
  bands <150 / 150-600 / 600-2k / 2-6k / >6k Hz, late part (150 ms on): [-81.0, -76.0, -87.0, -68.0, -148.0] dB/s  ->  T60 [0.74, 0.79, 0.69, 0.88, 0.4] s
  early part (60-150 ms, body + early reflections): [None, -139.0, -108.0, -137.0, -158.0] dB/s
  Median envelope of all hits relative to peak (dB): {'10ms': 0.0, '30ms': -5.3, '50ms': -6.7, '100ms': -16.3, '150ms': -20.9, '200ms': -27.2}
  Snare-stem noise floor between hits: -84.2 dBFS.

LAYERS
 hard   rr1-4 : four distinct real hits, untouched (hard = how the record was played).
 medium rr1-4 : four other real hits with physics-informed lighter-stroke transforms (ESTIMATE - the record has no quiet hits):
                nominal -6 dB, gentle tilt above 3 kHz (-2.5 dB), wire decay x0.9, pitch glide x0.8, attack x0.95.
 soft   rr1-4 : four other real hits: nominal -12 dB, tilt above 2 kHz (-5 dB), wire decay x0.75, glide x0.5, attack x0.85.
 ghost  rr1-4 : four other real hits: nominal -20 dB, tilt above 1.5 kHz (-8 dB) + above 5 kHz (-4 dB), wire decay x0.6, glide x0.3, attack x0.7.
 Each layer has +/-0.7 dB random level scatter so no two files are volume copies.
 ZC_bmth_oneshot.wav = hard rr1.

THE 16 HITS (time in song, air before next snare, background under the tail rel. peak, real tail used to, file length)
  hard rr1: t=26.47 s, gap 932 ms, bg -45.2 dB, real to 269 ms, len 814 ms
  hard rr2: t=186.78 s, gap 618 ms, bg -41.0 dB, real to 199 ms, len 682 ms
  hard rr3: t=178.03 s, gap 616 ms, bg -36.7 dB, real to 169 ms, len 878 ms
  hard rr4: t=30.22 s, gap 930 ms, bg -37.1 dB, real to 259 ms, len 816 ms
  medium rr1: t=146.78 s, gap 930 ms, bg -36.5 dB, real to 154 ms, len 941 ms
  medium rr2: t=13.65 s, gap 776 ms, bg -35.6 dB, real to 224 ms, len 794 ms
  medium rr3: t=126.47 s, gap 929 ms, bg -41.8 dB, real to 214 ms, len 774 ms
  medium rr4: t=180.53 s, gap 617 ms, bg -39.5 dB, real to 244 ms, len 872 ms
  soft rr1: t=185.53 s, gap 616 ms, bg -38.4 dB, real to 199 ms, len 794 ms
  soft rr2: t=209.28 s, gap 929 ms, bg -41.6 dB, real to 244 ms, len 855 ms
  soft rr3: t=76.47 s, gap 927 ms, bg -49.1 dB, real to 254 ms, len 782 ms
  soft rr4: t=175.53 s, gap 616 ms, bg -36.6 dB, real to 219 ms, len 749 ms
  ghost rr1: t=183.03 s, gap 616 ms, bg -33.9 dB, real to 194 ms, len 833 ms
  ghost rr2: t=189.28 s, gap 617 ms, bg -34.2 dB, real to 154 ms, len 930 ms
  ghost rr3: t=80.22 s, gap 1244 ms, bg -32.5 dB, real to 189 ms, len 958 ms
  ghost rr4: t=211.78 s, gap 928 ms, bg -38.4 dB, real to 154 ms, len 765 ms